PixelShare Instructions:

1. Copy the index.html to /sdcard/Download on your Android device.
2. Open Termux and run:

pkg update && pkg install -y python wget unzip
cd /sdcard/Download
wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.zip
unzip ngrok-stable-linux-arm.zip
mv ngrok ~/ngrok && chmod +x ~/ngrok
python3 -m http.server 8080
~/ngrok http 8080

3. Open index.html in your browser to share files or upload site files.
4. Click "Check Ngrok URL" to display your public web address.
