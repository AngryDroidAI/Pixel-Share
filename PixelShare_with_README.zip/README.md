# 🎮 PixelShare - File & Website Sharing Tool for Android

**PixelShare** is a retro-themed file & website hosting tool that runs entirely on your Android device using [Termux](https://f-droid.org/packages/com.termux/). Share files or full static websites from your device — styled with a nostalgic DOS pixel UI.

---

## ✨ Features

- 🕹️ Retro pixel-style UI (DOS VGA font)
- 📂 Share local files via browser (download links)
- 📤 Upload static website files for hosting
- 🌍 Ngrok tunnel integration to expose your device to the web
- ⚙️ Fully offline-compatible (run from internal storage)
- 📱 Designed for Android + Termux

---

## 📦 How to Use (Android)

1. **Install [Termux](https://f-droid.org/packages/com.termux/)** via F-Droid
2. **Move `index.html`** to `/sdcard/Download`
3. **Open Termux**, and run:

```bash
pkg update && pkg install -y python wget unzip
cd /sdcard/Download
wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.zip
unzip ngrok-stable-linux-arm.zip
mv ngrok ~/ngrok && chmod +x ~/ngrok
python3 -m http.server 8080
~/ngrok http 8080
```

4. Open `index.html` in a browser to interact with:
   - Local file downloads
   - Website uploader
   - Ngrok tunnel checker

---

## 📤 Hosting Websites

- Upload an `index.html` or zipped site using the browser interface
- Then manually unzip or move them into `/sdcard/Download`
- They will be served via Python’s HTTP server at `http://localhost:8080`

---

## 🔓 Ngrok Integration

The interface includes a **"Check Ngrok URL"** button. This uses:
- Ngrok's local API (`http://127.0.0.1:4040/api/tunnels`)
- To display your live public link (e.g. `https://abc123.ngrok.io`)

---

## 🧱 Folder Contents

```
📁 PixelShare/
 ├── index.html          # Main UI
 ├── README.txt          # Offline usage guide
 └── README.md           # GitHub page description
```

---

## 🧠 Credits

- Font: **Perfect DOS VGA 437** by [Zephram](https://www.cdnfonts.com/perfect-dos-vga-437.font)
- Ngrok: [https://ngrok.com](https://ngrok.com) — tunnel service for exposing local servers
- Inspired by projects like [OnionShare](https://onionshare.org/) (but made for Android + web)

---

## 📜 License

MIT License — use, fork, and remix freely.

---

## 🚧 Future Ideas

- 🔐 Add password protection for downloads
- 🎨 CRT-style background animation
- 📱 Android APK version with WebView + built-in Ngrok

> PRs and forks are welcome!
