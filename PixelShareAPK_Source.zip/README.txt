This is the full source code for PixelShare APK.
Open in Android Studio or AIDE to build.
